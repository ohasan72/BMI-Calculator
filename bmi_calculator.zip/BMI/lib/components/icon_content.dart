import 'package:flutter/material.dart';
import '../constants.dart';

class IconContent extends StatelessWidget {
  IconContent({required this.genderName, required this.gendarIcon});
  final String genderName;
  final IconData gendarIcon;
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(gendarIcon, size: 80),
        SizedBox(height: 15),
        Text(genderName, style: kLablelTextStyle),
      ],
    );
  }
}
